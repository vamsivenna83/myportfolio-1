# Avneet Kaur's E-Portfolio

Hello Everyonne,

Welcome to my own portfolio's code repository. In this e-portfolio, I have used template by I-Portfolio.

Check out the live version here - [My Portfolio](https://avi-k-dua.github.io/)

Get Connected: [LinkedIn](https://www.linkedin.com/in/avneet-kaur-dua/)

